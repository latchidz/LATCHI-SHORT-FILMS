# 🎬 الفيلم القصير المتكامل: «سوار الذهب وشاشة الهاتف — اللي ما فيه خير لباباه، ما فيه خير ليا»
## النسخة الإخراجية النهائية الكاملة (13 مشهداً مترابطاً × 10 ثوانٍ = 130 ثانية | 15 صورة أصلية Lossless PNG)

---

## المشهد 01 — الاستعراض وإبراز السوار الذهبي
- **الحدث:** أمين ومريم يمشيان ويضحكان بجانب واجهات المحلات الفاخرة، والسوار الذهبي يلمع في معصم مريم
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_01/`:** `01_SCENE_01_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 01.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- SETTING & KEY PROP: Walking side by side along the sunny sidewalk of a prestigious upscale Algiers shopping avenue lined with Haussmannian limestone boutique arches in warm golden-hour sunlight; the gleaming 18k yellow-gold bracelet sparkles prominently on Meriem's raised right wrist.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:04.5] Smooth Backward-Leading Tracking Shot on 50mm ARRI Alexa lens favoring Amin on screen-left as he walks proudly beside Meriem, smiling boastfully and gesturing toward the gleaming gold bracelet on her wrist. Meriem smiles warmly with 100% closed lips.
- [00:04.5–00:05.6] Smooth Fluid Horizontal Pan + Slight Push-in toward Meriem on screen-right and her sunlit right wrist during a strict 1.1-second dialogue silence gap, clearly highlighting the sparkling 18k gold bracelet.
- [00:05.6–00:10.0] Steady Tracking Medium Close-up on Meriem laughing happily and admiring the gold bracelet on her wrist as they continue strolling down the sunlit avenue. ZERO direct eye contact with camera lens.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, zero voice overlap):
- [00:00.4–00:04.5] ONLY AMIN SPEAKS (24yo confident boastful young Algerian baritone; Meriem's lips 100% closed):
  أمين: "شوفي يا مريم، هاذ السوار الذهبي ما يليق غير بيدك... مع أمين حياتك كامل عزّ ودلال."
- [00:04.5–00:05.6] [STRICT 1.1s SILENCE GAP — soft upscale street footsteps and golden bracelet shimmer]
- [00:05.6–00:09.5] ONLY MERIEM SPEAKS (19yo charmed joyful young Algerian female soprano-mezzo; Amin's lips 100% closed):
  مريم: "يعيشك يا أمين، ذوقك ديما يهبل... معاك نحس روحي أميرة."

AUDIO:
Crisp leather shoes and heels walking on sunlit stone sidewalk, faint metallic shimmer of gold bracelet, gentle Algiers afternoon breeze. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 02 — سقوط السوار وملاحظة الأب له (Start + End)
- **الحدث:** صورة البداية: السوار الذهبي ينزلق على الرصيف خلفهما دون انتباه ← صورة النهاية: الأب يلمح بريق الذهب وينحني بأمانة لالتقاطه
- **النمط:** `Start & End Dual Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_02/`:** `02A_SCENE_02_START_9x16.png, 02B_SCENE_02_END_9x16.png`

```text
Starting directly from the uploaded Start Image of Scene 02 and transitioning smoothly in one unbroken 10.0-second continuous camera movement to match the exact uploaded End Image of Scene 02.

[DURATION: Exactly 10.0 seconds | MODE: Google Flow First & Last Frame (Start Image + End Image) | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- THE FATHER (62-year-old hardworking elderly Algerian street cleaner): deeply sun-weathered olive-tan wrinkled face with subtle forehead prayer mark, crow's feet, tired under-eye hollows, kind soulful bare dark-brown eyes (strictly NO glasses), thinning short grey-white hair, short trimmed salt-and-pepper grey-white beard and moustache, wearing a sun-faded dusty municipal olive-green street-cleaner work jacket with worn scuffed grey reflective safety stripes over a faded grey-beige collarless undershirt, dusty dark-olive work trousers, and scuffed black work shoes.
- COUPLE WALKING AWAY IN DEPTH: Amin (midnight-navy blazer, cream trousers, short high skin-fade dark hair) and Meriem (golden-blonde wavy hair, ivory-cream tweed blazer, black wide-leg trousers, cream quilted gold-chain bag, bare right wrist) continue walking away unaware down the sunlit Algiers stone sidewalk.
- KEY PROP: Gleaming luxury 18k yellow-gold Cuban-link bracelet resting on the sunlit beige limestone sidewalk tiles.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS START-TO-END SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:03.2] Low Ground-Level Focus on the gleaming 18k yellow-gold bracelet settling onto the sunlit stone pavement tiles in the foreground while Amin and Meriem stroll farther away in the background completely oblivious.
- [00:03.2–00:06.8] Smooth Fluid Lateral Glide and Tilt-Up across the sunlit stone pavement toward the opposite curbside as the 62-year-old Street-Cleaner Father (holding his wooden broom in his left hand) spots the bright golden sun-glint of the fallen bracelet on the stone tiles and steps honestly toward it.
- [00:06.8–00:10.0] Settling seamlessly into the exact End Image composition: the elderly Father bends forward at the waist beside the black lamppost, reaching his weathered right hand gently down toward the sparkling gold bracelet on the pavement with pure surprise and honesty. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, single speaker):
- [00:00.0–00:06.8] [6.8s pure visual suspense — delicate metallic ring of gold hitting stone tiles, receding footsteps of the couple, and shuffling work-shoe steps of the Father]
- [00:06.8–00:09.7] ONLY THE FATHER SPEAKS (62yo warm, honest, weathered elderly Algerian father bass-baritone):
  الأب: "سبحان الله... هذا ذهب طاح من هاديك البنت، لازم نلحقها بيه!"

AUDIO:
Delicate crisp metallic clink of 18k gold bracelet landing on stone, footsteps fading down the sidewalk, soft brush of wooden broom, authentic quiet street ambience. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 03 — الشهامة والأمانة
- **الحدث:** الأب يهرول لاهثاً ببدلة العمل الخضراء الباهتة مادّاً يده بالسوار الذهبي وينادي لإرجاعه
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_03/`:** `03_SCENE_03_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 03.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- THE FATHER (62-year-old hardworking elderly Algerian street cleaner): deeply sun-weathered olive-tan wrinkled face with subtle forehead prayer mark, crow's feet, tired under-eye hollows, kind soulful bare dark-brown eyes (strictly NO glasses), thinning short grey-white hair, short trimmed salt-and-pepper grey-white beard and moustache, wearing a sun-faded dusty municipal olive-green street-cleaner work jacket with worn scuffed grey reflective safety stripes over a faded grey-beige collarless undershirt, dusty dark-olive work trousers, and scuffed black work shoes.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap (her right wrist is bare while the Father holds her fallen gold bracelet).
- SETTING & CONTINUITY FROM SCENE 02: Same sunlit upscale Algiers boulevard from a reverse-diagonal tracking angle; the Father hurries forward in the right-center foreground holding up the gleaming 18k gold bracelet in his weathered right hand while Amin and Meriem pause ahead on screen-left turning back.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:05.8] Dynamic Tracking Medium Shot moving smoothly alongside the 62-year-old Street-Cleaner Father as he hurries breathlessly forward in his faded olive-green uniform, holding out the gleaming 18k yellow-gold bracelet clearly in his hand and calling politely after Meriem. Amin and Meriem keep their mouths 100% closed as they stop and turn around ahead.
- [00:05.8–00:07.2] Smooth Fluid Pan and Push-in shifting focus past the Father's outstretched hand onto Amin and Meriem turning fully around on the sunlit sidewalk.
- [00:07.2–00:10.0] Tense Dramatic Hold on Amin freezing in sudden pale panic behind his emerald-gold sunglasses upon recognizing his own father in street-cleaner clothes, while Meriem looks down haughtily at the dusty old man approaching her. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, single speaker):
- [00:00.8–00:06.2] ONLY THE FATHER SPEAKS (62yo breathless, noble, kind elderly Algerian bass-baritone; Amin and Meriem's lips 100% closed):
  الأب: "يا بنتي! استناي يا بنتي الله يحفظك... طاحلك هاذ السوار الذهبي في الطريق!"
- [00:06.2–00:10.0] [3.8s tense silent cliffhanger — heavy breathless panting of the elderly Father and Amin's stunned frozen dread]

AUDIO:
Hurried scuffed work-shoe footsteps on stone, honest breathless elderly voice, sudden tense hush as Amin recognizes his father. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 04 — اشمئزاز مريم وإهانتها للأب
- **الحدث:** مريم تخطف سوارها الذهبي بأطراف أصابعها باشمئزاز وتصرخ في الأب، والأب المصدوم ينظر نحو ابنه أمين الواقف متجمداً
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_04/`:** `04_SCENE_04_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 04.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap (with bare wrists as she snatches her single gleaming 18k yellow-gold bracelet out of the cleaner's hand).
- THE FATHER (62-year-old hardworking elderly Algerian street cleaner): deeply sun-weathered olive-tan wrinkled face with subtle forehead prayer mark, crow's feet, tired under-eye hollows, kind soulful bare dark-brown eyes (strictly NO glasses), thinning short grey-white hair, short trimmed salt-and-pepper grey-white beard and moustache, wearing a sun-faded dusty municipal olive-green street-cleaner work jacket with worn scuffed grey reflective safety stripes over a faded grey-beige collarless undershirt, dusty dark-olive work trousers, and scuffed black work shoes.
- SETTING & CONTINUITY FROM SCENE 03: Sunlit Algiers stone sidewalk beside classic limestone storefront arches; Meriem (center) snatches her 18k gold bracelet back away from the Father's weathered outstretched hand (screen-right) with open disgust while Amin stands stiffly frozen on screen-left.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:04.6] Slow Cinematic Push-in onto Meriem (center) as she snatches her gold bracelet sharply out of the Father's hand, recoiling half a step with exaggerated upper-class disgust while shouting harshly at his dusty work clothes. Father and Amin keep their mouths 100% closed.
- [00:04.6–00:05.7] Smooth Fluid Horizontal Pan from Meriem across to the elderly Father on screen-right during a strict 1.1-second dialogue silence gap.
- [00:05.7–00:10.0] Steady Heartbreaking Medium Close-up on the Father's stunned, wounded wrinkled face as he lowers his empty hands and looks past Meriem straight at Amin, whispering softly in disbelief to his son. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, zero voice overlap):
- [00:00.3–00:04.6] ONLY MERIEM SPEAKS (19yo sharp, disgusted, haughty young Algerian female voice; Father and Amin's lips 100% closed):
  مريم: "هات سواري وبعد يديك الموسخين عليا! ما تشوفش حالتك كي دايرة؟!"
- [00:04.6–00:05.7] [STRICT 1.1s SILENCE GAP — sharp snatch of gold chain and hurt intake of breath]
- [00:05.7–00:09.6] ONLY THE FATHER SPEAKS (62yo quiet, wounded elderly Algerian father bass-baritone looking toward Amin; Meriem and Amin's lips 100% closed):
  الأب: "أنا غير حبيت نرجع الأمانة... أمين، وليدي، راك تشوف؟"

AUDIO:
Metallic snatch of gold bracelet, crisp blazer rustle, raw wounded elderly whisper, quiet outdoor Algiers street air. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 05 — جحود أمين وطرده القاسي لأبيه
- **الحدث:** أمين يتقدم ببرود وغرور بين مريم وأبيه ويطرده بقسوة خوفاً من انكشاف سرّه، والأب ينكسر صامتاً
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_05/`:** `05_SCENE_05_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 05.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- THE FATHER (62-year-old hardworking elderly Algerian street cleaner): deeply sun-weathered olive-tan wrinkled face with subtle forehead prayer mark, crow's feet, tired under-eye hollows, kind soulful bare dark-brown eyes (strictly NO glasses), thinning short grey-white hair, short trimmed salt-and-pepper grey-white beard and moustache, wearing a sun-faded dusty municipal olive-green street-cleaner work jacket with worn scuffed grey reflective safety stripes over a faded grey-beige collarless undershirt, dusty dark-olive work trousers, and scuffed black work shoes.
- SETTING & CONTINUITY FROM SCENE 04: Exact same sunlit upscale Algiers sidewalk; Amin steps sharply between Meriem (behind his left shoulder) and his elderly Street-Cleaner Father (screen-right) to silence and chase him away before Meriem realizes the truth.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:05.2] Slow Cinematic Push-in on Amin (center-left) as terror of exposure turns into cruel arrogance; he raises one cold dismissive hand toward his elderly Father without touching him and shouts harshly, denying him and ordering him away. Father and Meriem keep their mouths 100% closed.
- [00:05.2–00:06.3] Smooth Fluid Horizontal Pan from Amin right onto a tight Medium Close-up of the Father's shattered face on screen-right.
- [00:06.3–00:10.0] Devastating Silent Close-up Hold on the 62-year-old Father: tears well up in his bare dark-brown eyes, his weathered chin trembles violently, yet he keeps his mouth closed in noble silence so he does not humiliate his own son, bowing his head brokenly. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, single speaker):
- [00:00.3–00:05.2] ONLY AMIN SPEAKS (24yo harsh, cold, defensive young Algerian baritone; Father and Meriem's lips 100% closed):
  أمين: "شكون نتا باش تعيّطلي وليدي؟! روح تشوف لخدمتك يا شيخ وما تزيدش تدور جيهتنا!"
- [00:05.2–00:10.0] [4.8s DEVASTATING SILENT HEARTBREAK — Father's silent glistening tears, trembling jaw, and bowed head; zero speech]

AUDIO:
Harsh cold echo of Amin's voice, followed by heavy stunned silence, a faint trembling breath from the broken Father, and soft city wind. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 06 — داخل المقهى الفاخر: الحديث عن الخطوبة والزواج
- **الحدث:** أمين جالس جنباً إلى جنب بجانب مريم على نفس الأريكة المخملية يحكيان بحب وتفاخر عن خطوبتهما وعرسهما الفخم
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_06/`:** `06_SCENE_06_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 06.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- NEW LOCATION (LUXURY INDOOR ALGIERS CAFÉ — ENGAGEMENT & WEDDING TALK): Inside an ultra-elegant dark-walnut luxury Algiers café lounge with glowing warm brass sconces, cream-and-emerald velvet seating, and a brass-trimmed dark-veined marble table holding two porcelain espresso cups and Amin's sleek Space-Black iPhone Pro. Amin sits closely side-by-side right next to Meriem shoulder-to-shoulder on the same plush cream velvet booth seat behind the marble table, leaning warmly toward her as they chat affectionately about their engagement and upcoming luxury wedding.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:04.8] Warm Intimate Medium Two-Shot pushing slowly in on Amin seated right beside Meriem on screen-left as he smiles boastfully, gesturing warmly while promising her the grandest VIP wedding hall in Algiers. Meriem listens affectionately with 100% closed lips.
- [00:04.8–00:05.8] Smooth Fluid Pan slightly right onto Meriem seated beside him during a strict 1.0-second silence gap.
- [00:05.8–00:10.0] Steady Intimate Focus on Meriem smiling dreamily and resting her braceleted hand warmly near the marble table beside Amin's dark iPhone, expressing how proud she is of their engagement. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, zero voice overlap):
- [00:00.4–00:04.8] ONLY AMIN SPEAKS (24yo charming boastful young Algerian baritone; Meriem's lips 100% closed):
  أمين: "عرسنا يا مريم راح نديرهولك في أفخم قاعة في الدزاير... غير الناس الكبار اللي يحضروا في خطوبتنا."
- [00:04.8–00:05.8] [STRICT 1.0s SILENCE GAP — warm upscale café atmosphere and soft porcelain clink]
- [00:05.8–00:09.6] ONLY MERIEM SPEAKS (19yo affectionate proud young Algerian female soprano-mezzo; Amin's lips 100% closed):
  مريم: "تعيش يا أمين... علابيها اخترتك نتا، نحب الراجل اللي يعرف قيمتي ومقامي."

AUDIO:
Warm intimate luxury Algiers lounge ambience, soft porcelain espresso cup clink, natural conversational voices. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 07 — أمين يستأذن لدفع الحساب ويترك هاتفه iPhone فوق الطاولة
- **الحدث:** أمين ينهض مبتسماً ليذهب لدفع الحساب عند الصندوق، ويترك هاتفه الأسود منسياً فوق الطاولة الرخامية أمام مريم
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_07/`:** `07_SCENE_07_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 07.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- SETTING & CONTINUITY FROM SCENE 06: Exact same dark-walnut luxury Algiers café lounge and brass-trimmed marble table; Amin stands smoothly beside his armchair buttoning his midnight-navy blazer to go pay the bill at the cashier, leaving his sleek Space-Black iPhone Pro lying forgotten on the marble table directly in front of Meriem.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:04.8] Medium Two-Shot with Slow Subtle Push-in: Amin stands beside his chair on screen-left buttoning his navy blazer with a confident smile toward Meriem while leaving his Space-Black iPhone Pro resting forgotten on the marble tabletop in front of her. Meriem's lips stay 100% closed.
- [00:04.8–00:05.8] Smooth Fluid Tilt-and-Pan shifting right onto Meriem seated gracefully at the table with Amin's black iPhone visible in the lower foreground during a strict 1.0-second silence gap as Amin steps away out of frame.
- [00:05.8–00:10.0] Steady Medium Focus on Meriem smiling lightly and reaching softly for her espresso cup while Amin's dark iPhone sits untouched right before her on the marble table. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, zero voice overlap):
- [00:00.4–00:04.8] ONLY AMIN SPEAKS (24yo warm confident young Algerian baritone; Meriem's lips 100% closed):
  أمين: "اقعدي مرتاحة يا مريم، نروح نخلّص الحساب عند لاكاس ونولّي ليك ثمّ ثمّ."
- [00:04.8–00:05.8] [STRICT 1.0s SILENCE GAP — soft blazer rustle and Amin's footsteps stepping away]
- [00:05.8–00:09.0] ONLY MERIEM SPEAKS (19yo calm pleasant young Algerian female soprano-mezzo):
  مريم: "أوكي حبيبي، راني نستناك هنا."

AUDIO:
Quiet luxury indoor Algiers café ambience, soft clink of porcelain saucer, subtle footsteps walking away across polished floor. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 08 — وصول الإشعار وإضاءة شاشة الهاتف فوق الطاولة (Start + End)
- **الحدث:** صورة البداية: شاشة الهاتف سوداء منطفئة ← صورة النهاية: إشعار يضيء شاشة القفل فتظهر صورة الأم والأب وحدهما، وتمتد يد مريم لالتقاط الهاتف
- **النمط:** `Start & End Dual Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_08/`:** `08A_SCENE_08_START_9x16.png, 08B_SCENE_08_END_9x16.png`

```text
Starting directly from the uploaded Start Image of Scene 08 and transitioning smoothly in one unbroken 10.0-second continuous camera movement to match the exact uploaded End Image of Scene 08.

[DURATION: Exactly 10.0 seconds | MODE: Google Flow First & Last Frame (Start Image + End Image) | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- KEY PROP TRANSITION (DARK SCREEN -> NOTIFICATION GLOW): Amin's sleek Space-Black iPhone Pro resting face-up on the exact dark-veined marble café table in front of Meriem. In Start Image the OLED screen is completely pitch-black off; in End Image the screen illuminates brightly with a notification banner, displaying a warm family Lock-Screen Wallpaper photo of ONLY two people: his Algerian hijabi Mother and his exact 62-year-old Father dressed in clean neat home clothes. Amin must NOT appear in the wallpaper; no third person, as Meriem leans forward reaching her hand to pick up the glowing phone.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS START-TO-END SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:03.0] High-Angle Over-the-Table Close-Medium Focus holding tensely on Amin's pitch-black dark iPhone resting still on the marble café table near Meriem's braceleted right hand.
- [00:03.0–00:06.8] With a crisp vibration buzz, the iPhone OLED screen suddenly lights up brightly with an incoming message notification banner, illuminating the family Lock-Screen Wallpaper of ONLY his hijabi Mother and his exact elderly Father in clean clothes; Amin is absent from the photograph! Meriem's gaze snaps downward in sudden curiosity.
- [00:06.8–00:10.0] Smooth Slow Push-in settling into the exact End Image composition: Meriem leans forward with furrowed brows and reaches her right hand directly onto the glowing iPhone on the marble table to lift and inspect the photograph up close. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Pure Visual Suspense, zero spoken words):
- [00:00.0–00:03.0] [Quiet luxury café stillness]
- [00:03.0–00:03.8] [Realistic smartphone vibration hum against marble tabletop + soft single glass notification chime]
- [00:07.2–00:10.0] [Soft puzzled intake of breath from Meriem as her fingers touch the glowing phone]

AUDIO:
Crisp realistic iPhone vibration buzz on marble, single subtle notification chime, delicate clink of Meriem's gold bracelet as she reaches for the phone. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 09 — لقطة مقربة من خلف مريم وهي تمسك الهاتف المشتغل
- **الحدث:** من خلف مريم وكتفها نرى يديها وهي تمسك iPhone وتنظر إلى شاشة مضيئة بصورة واضحة للأم والأب فقط، بدون أمين؛ الأب بنفس وجه عامل النظافة وبملابس بيت نظيفة.
- **النمط:** `Macro Close-Up Reveal (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_09/`:** `09_SCENE_09_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 09.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- REAR OVER-THE-SHOULDER CLOSE-UP AND PHONE LOCK SCREEN: Camera is behind and slightly above Meriem, looking past the back of her champagne-blonde hair and cream bouclé blazer toward the phone she herself naturally holds upright in both hands and looks down at. Do not show her face to camera. Her right wrist retains the single gold bracelet. The lit Space-Black iPhone Pro fills the center, in tack-sharp focus, and displays realistic iOS details (Dynamic Island, lock-screen clock, and a WhatsApp notification from “أمي الغالية ❤️”). The full-screen family photograph shows EXACTLY TWO people: Amin’s kind hijabi Algerian mother and his 62-year-old father, side by side at home. The father has the same weathered face and grey-white beard as the street cleaner, but wears a clean white collared shirt and beige cardigan. Absolutely no Amin and no third person in the wallpaper.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:05.2] Rear over-the-shoulder close-up: keep Meriem’s blonde head and cream-clad shoulder in the foreground and her own two hands on the same illuminated iPhone in front of her. Slow, gentle push-in toward the readable two-person photograph as she studies her mother-in-law and recognizes the cleaner’s face. The room and table remain the same; DO NOT MIRROR THE ROOM.
- [00:05.2–00:10.0] Hold the camera behind Meriem, showing no frontal view of her face. Her shoulders subtly stiffen and her fingers tremble around the phone as she realizes who the man is and whispers. Keep the mother’s and father’s faces, and only those two faces, steady on the lit screen. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, single speaker):
- [00:00.0–00:04.5] [4.5s tense breathless silence — Meriem's fingers tremble slightly holding the glowing iPhone as her eyes scan the Father and Mother's faces on the screen]
- [00:04.5–00:09.6] ONLY MERIEM SPEAKS (19yo shocked, hushed, trembling Algerian female whisper):
  مريم: "مستحيل... هاذا هو نفس الشيخ مسكين تاع الطريق! صافي هذا باباه اللي طردو قدّامي؟!"

AUDIO:
Subtle trembling hand movement on phone frame, sharp stunned gasp, hushed trembling whisper in quiet café air. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, extraneous text, watermarks, background music. The intended native iPhone UI and notification remain visible.
```

---

## المشهد 10 — عودة أمين وتصنّع مريم للهدوء
- **الحدث:** مريم تعيد الهاتف للطاولة وتخفي صدمتها بهدوء بارد لحظة عودة أمين وجلوسه بابتسامة واثقة
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_10/`:** `10_SCENE_10_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 10.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- SETTING & CONTINUITY FROM SCENE 09: Exact same luxury indoor Algiers café marble table; Meriem has placed the dark iPhone back down onto the marble tabletop just as Amin returns and sits comfortably in the left armchair with a relaxed confident smile, while Meriem sits straight-backed on screen-right masking her shock behind icy, calculating composure.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:04.6] Slow Cinematic Push-in favoring Amin on screen-left as he settles comfortably into his chair, adjusts his blazer cuff, and smiles warmly at Meriem completely unaware his secret has been discovered. Meriem watches him silently with 100% closed lips.
- [00:04.6–00:05.7] Smooth Fluid Horizontal Pan across the marble café table to Meriem on screen-right during a strict 1.1-second silence gap.
- [00:05.7–00:10.0] Steady Psychological Medium Close-up on Meriem: she forces a cold, controlled calm, folding her hands near the dark iPhone on the table and speaking in a quiet, measured tone to begin her psychological trap. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, zero voice overlap):
- [00:00.4–00:04.6] ONLY AMIN SPEAKS (24yo relaxed, cheerful young Algerian baritone; Meriem's lips 100% closed):
  أمين: "راني خلّصت كلش... واش بيك يا مريم راكي ساهية؟ نروحو نكملو سهرتنا؟"
- [00:04.6–00:05.7] [STRICT 1.1s SILENCE GAP — tense unspoken eye contact across the café table]
- [00:05.7–00:09.6] ONLY MERIEM SPEAKS (19yo dangerously calm, controlled Algerian female voice; Amin's lips 100% closed):
  مريم: "لا والو يا أمين... غير كنت نخمّم في حاجة صراتلنا مقبل برا."

AUDIO:
Subtle chair/suit fabric settle, quiet indoor Algiers café ambience, crisp intimate vocal tension. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 11 — الاستدراج النفسي والوقوع في الفخ
- **الحدث:** مريم تختبر أمين بهدوء: «والله غير هذاك الشيخ تاع مقبل غاضني بزاف..» وأمين يتمادى في تكبره وشتم أبيه مجدداً!
- **النمط:** `Single Frame (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_11/`:** `11_SCENE_11_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 11.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- SETTING & CONTINUITY FROM SCENE 10: Exact same luxury indoor Algiers café marble table; Meriem (screen-right) leans slightly forward testing Amin with deliberate sympathy for the elderly street cleaner, while Amin (screen-left) falls straight into her trap with arrogant disdain.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:04.4] Steady Tight Medium Focus on Meriem (screen-right) looking directly at Amin and speaking with calm, probing empathy about the old street cleaner who returned her gold bracelet. Amin listens with 100% closed lips, flinching subtly.
- [00:04.4–00:05.4] Smooth Fluid Horizontal Pan from Meriem across the table to Amin on screen-left during a strict 1.0-second silence gap.
- [00:05.4–00:10.0] Slow Cinematic Push-in on Amin as brief nervousness hardens into ugly, boastful arrogance; he scoffs dismissively with a wave of his hand, insulting his own father once again while Meriem's eyes narrow in cold fury. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, zero voice overlap):
- [00:00.3–00:04.4] ONLY MERIEM SPEAKS (19yo calm, probing young Algerian female voice; Amin's lips 100% closed):
  مريم: "والله غير هذاك الشيخ تاع مقبل غاضني بزاف... مسكين دار الخير ورجّعلنا الذهب."
- [00:04.4–00:05.4] [STRICT 1.0s SILENCE GAP — nervous swallow from Amin]
- [00:05.4–00:09.7] ONLY AMIN SPEAKS (24yo arrogant, scoffing young Algerian baritone; Meriem's lips 100% closed):
  أمين: "ما يغيدك ما والو! هاذوك الناس طمّاعين وماشي من مستوانا خلاص!"

AUDIO:
Quiet tense indoor café air, faint rustle of blazer sleeve, sharp contrast between Meriem's calm trap and Amin's arrogant scoff. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 12 — الانفجار والمواجهة بشاشة الهاتف في وجه أمين
- **الحدث:** مريم تقف غاضبة وتوجّه شاشة الهاتف المضيئة بصورة أبيه وأمه في وجه أمين المصدوم: «اللي ما فيه خير لباباه.. ما فيه خير ليا!» وتغادر
- **النمط:** `Climax Confrontation (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_12/`:** `12_SCENE_12_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 12.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- MERIEM (19-year-old wealthy Algerian young woman): fair-warm Mediterranean skin with natural pores, expressive bare hazel-green eyes (strictly NO glasses), refined features, long voluminous golden champagne-blonde wavy hair past her shoulders, wearing a tailored ivory-cream bouclé-tweed designer blazer with gold buttons over a sleek black silk mock-neck top, tailored black high-waisted wide-leg trousers, delicate 18k gold pendant necklace, pearl stud earrings, carrying her structured quilted cream-white leather handbag with a polished gold chain strap, and wearing a gleaming 18k yellow-gold chain link bracelet on her right wrist.
- AMIN (24-year-old Algerian man): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut with short dark textured top hair, neat ~1cm trimmed black beard and moustache, wearing his signature rimless octagonal-rectangular emerald-teal dark gradient sunglasses with polished gold nose bridge and gold spear-point hinges, a bespoke midnight-navy wool-linen luxury blazer with a crisp white pocket-square tip over an immaculate white dress shirt (top collar button open, no tie), tailored cream-ivory dress trousers, and a two-tone silver-and-gold chronograph watch on his left wrist. ONLY Amin wears sunglasses.
- CLIMAX CONFRONTATION PROP: Meriem stands furiously beside the exact marble café table clutching her cream quilted gold-chain handbag in her left hand while thrusting Amin's glowing Space-Black iPhone Pro—vividly displaying the same family wallpaper of ONLY his hijabi Mother and clean-dressed Father, with no Amin or third person in the photograph—straight into seated Amin's stunned, pale face.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:06.8] High-Intensity Dramatic Two-Shot pushing slowly in on standing Meriem (screen-right) as she holds the glowing family-wallpaper iPhone screen inches from seated Amin's paralyzed face (screen-left) and delivers her devastating rebuke with blazing moral disgust. Amin sits frozen in shock with 100% closed lips.
- [00:06.8–00:10.0] Smooth Fluid Pan/Reframe as Meriem sets the iPhone sharply down onto the marble café table, grips her cream quilted handbag decisively, and strides forcefully away out of frame, leaving Amin completely petrified. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, single speaker):
- [00:00.4–00:06.8] ONLY MERIEM SPEAKS (19yo fierce, trembling, cutting Algerian female voice; Amin's lips 100% closed):
  مريم: "هاذ الطمّاع اللي تحكي عليه هو باباك اللي ربّاك!! اللي ما فيه خير لباباه.. ما فيه خير ليا!"
- [00:06.8–00:10.0] [Sharp clack of iPhone placed onto the marble tabletop + Meriem's brisk decisive heel footsteps walking away]

AUDIO:
Powerful emotional female voice resonating in the hushed café, sharp clack of phone hitting marble table, decisive footsteps exiting. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```

---

## المشهد 13 — الخاتمة والندم القاتل وحيداً في المقهى
- **الحدث:** أمين وحيداً منكسراً بلا نظارات يمسك رأسه بين يديه والدموع تنهمر من عينيه أمام الكرسي الفارغ ونظارته الموضوعة على الطاولة
- **النمط:** `Finale Pull-Back (10s)`
- **الصور المرجعية في مجلد `SCENES/SCENE_13/`:** `13_SCENE_13_START_9x16.png`

```text
Starting directly from the uploaded reference image of Scene 13.

[DURATION: Exactly 10.0 seconds | FORMAT: Vertical 9:16 Photorealistic 35mm Cinema | SINGLE CONTINUOUS UNBROKEN TAKE]

VISUAL CONTINUITY & IDENTITY LOCK:
Preserve 100% the exact visual appearance, precise facial features, hair color, clothing, accessories, and lighting from the uploaded reference image.
- AMIN (24-year-old Algerian man, bare-eyed without sunglasses): exact unfiltered North African facial bone structure, natural skin pores, clean high skin-fade haircut, neat ~1cm trimmed black beard and moustache, bare dark-brown eyes reddened and overflowing with real tears of crushing remorse, wearing his bespoke midnight-navy blazer with white pocket-square tip over unbuttoned crisp white dress shirt, cream-ivory trousers, and two-tone chronograph watch.
- SETTING & PROPS CONTINUITY FROM SCENE 12: Seated completely alone at the exact marble table inside the quiet luxury Algiers café; Meriem's opposite chair sits empty, while Amin's removed rimless emerald-gold sunglasses and his Space-Black iPhone rest untouched on the marble tabletop beside the cold espresso cups.

CAMERA & MOTION (10.0s SINGLE CONTINUOUS SHOT):
Maintain absolute identity consistency during any camera movements (e.g., Smooth Pan, Push-in). Modify ONLY the characters' facial expressions (shock, crying, anger, arrogance) and required limb/body movements as described in the timeline. Strictly DO NOT alter their base identity, outfits, or physical structure.
- [00:00.0–00:03.5] Intimate Emotional Medium Close-up on solitary, bare-eyed Amin slumped forward at the café table, tears streaming down his face as his trembling hands rise to grip his head in unbearable shame.
- [00:03.5–00:10.0] Slow Cinematic Pull-Back (Dolly Out) gradually widening across the empty opposite chair and quiet luxury café lounge as Amin buries his head between both hands, left completely alone after losing both his father's dignity and his fiancée through his own arrogance. ZERO lens gaze.

DIALOGUE & HARD-GAPPED TURN-TAKING (Natural Algerian Darija, single speaker):
- [00:00.0–00:03.2] [3.2s heavy trembling sobbing breath and broken sigh]
- [00:03.2–00:09.2] ONLY AMIN SPEAKS (24yo broken, tear-choked, remorseful whispery Algerian baritone):
  أمين: "يا ربي واش درت في روحي... بعت بابا قدّام الناس، وخسرت كلش بيدي."

AUDIO:
Quiet hollow indoor café silence, trembling broken whisper, soft rustle of hands gripping hair. Strictly zero background music.

NEGATIVE: morphing, changing clothes, face swapping, losing facial features, inconsistent identity, changing hair color, changing accessories, structural deformation, mutating bodies, jump cuts, direct eye contact with camera lens, extra fingers, deformed hands, subtitles, captions, on-screen text, watermarks, background music.
```
