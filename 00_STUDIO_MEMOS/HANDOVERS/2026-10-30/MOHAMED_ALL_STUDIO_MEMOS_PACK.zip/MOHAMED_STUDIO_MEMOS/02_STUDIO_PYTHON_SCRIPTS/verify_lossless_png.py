#!/usr/bin/env python3
"""Verify and save bit-exact Lossless PNG files (compress_level=9, zero pixel loss)."""
import sys
import numpy as np
from PIL import Image

def save_verified_lossless_png(src_path: str, dst_path: str) -> None:
    im = Image.open(src_path)
    im.save(dst_path, format="PNG", compress_level=9)
    assert np.array_equal(np.array(im), np.array(Image.open(dst_path))), f"Lossless check failed on {dst_path}!"
    print(f"Verified 100% bit-exact Lossless PNG: {dst_path} -> {im.size}")

if __name__ == "__main__":
    for p in sys.argv[1:]:
        save_verified_lossless_png(p, p)
